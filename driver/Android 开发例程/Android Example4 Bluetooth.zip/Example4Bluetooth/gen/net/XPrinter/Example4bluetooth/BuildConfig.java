/** Automatically generated file. DO NOT MODIFY */
package net.XPrinter.Example4bluetooth;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}